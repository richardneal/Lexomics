// diviText is a graphical text segmentation tool for use in text mining.
//     Copyright (C) 2011 Amos Jones and Lexomics Research Group
// 
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
// 
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
// 
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

// memory skimping time
// sacrifice a little bit of speed for mucho space saving
//

// um, a 'const'
var MAX_WORDS = 75000;

ChunkViewer = Ext.extend( Ext.list.ListView, {

    border: false,
    
	// 
    emptyText: 'No Chunks???',
    root: 'chunks',
    cpid: 'cp',

	columnSort: false,

    columns: [{
        header: 'Chunk',
        dataIndex: 'chunk',
        align: 'right'
    },{
        header: 'Start',
        dataIndex: 'start',
        align: 'right'
    },{
        header: 'End',
        dataIndex: 'end',
        align: 'right'
    },{
        header: 'Length',
        tpl: '{[values.end-values.start+1]}', 
        align: 'right'
    }],

    store: new Ext.data.JsonStore({
        root: 'chunks',
        fields: [
            {
                name: 'chunk',
                type: 'int'
            },
            {
                name: 'start',
                type: 'int'
            },
            {
                name: 'end',
                type: 'int'
            }
        ]
    }),

    listeners: {
        resize: function() {
            
        },
        click: function( t, i, n, e ) {
            var cp = Ext.getCmp( this.cpid );
            var word = t.store.getAt(i).get('start')-1;
            var w = Ext.get( cp.data.cmp + word );
            if ( !w )
                return;
            w.dom.scrollIntoView();
            w.highlight('ff0000', {
                easing: 'easeOut',
                duration: 2
            });
            word = t.store.getAt(i).get('end')-1;
            w = Ext.get( cp.data.cmp + word );
            w.highlight('ff0000', {
                easing: 'easeOut',
                duration: 2
            });
        }
    }

});

CutterPanel = Ext.extend( Ext.Panel, {

	// config vars
    
    id: 'cp',
    tid: null,

	cls: 'cp-panel-cursor cp-panel-align cp-panel-overflow',

	autoScroll: true,

	padding: 5,

	colors: [ '#ffdead', '#fffacd', '#e0eee0', '#eed5b7' ],

	updater: new ChunkViewer({
		id: 'cp-cv'
	}),
	
	// data

	textData: '',

	// public functions
    
    reset: function() {
        this.emptySpaces();
        this.updateTable();
    },

	threeParamSpacer: function( size, shift, last ) {
		this.emptySpaces();

        var spaces = [];
		shift = size;
        var t;
		var curr = size - 1;
		for ( ; curr < this.data.tN; curr = curr + shift )
		{
            t = Ext.get( this.data.cmp + curr );
			//this.clickSpace( null, t, null, true );
            spaces.push( curr );
		}

		var cut = curr - shift;
		var lastlen = this.data.tN - cut;
		if ( ( lastlen / size ) > last && lastlen != 1)
		{
			// make sure that the size of the new chunk won't be 0
		}
		else
		{
            //this.clickSpace( null, t, null, true );
            spaces.pop();
		}

        this.setSpaces( spaces );
        this.updateTable();
	},

	oneParamSpacer: function( chunks ) {
		var size = this.data.textArray.length / chunks;
		size = Math.round( size );
		this.threeParamSpacer( size, size, .5 );
	},

    updateTable: function( e, t, o ) {
        // if a click event
        if ( e )
            r = Ext.getCmp( this.id );
        else
            r = this;

        // if it is a click, get the id of the target and make
        // sure it is a word
        if ( e )
        {
            if ( !e.target.id.match( r.data.cmp ) )
                return;
        }

        var waiter = Ext.Msg.wait( "Please be patient. This may take a while" + 
            " for large texts.", "Updating Visual Cutter" );
		
        var list = r.updater;
	
		var rows = [];
		var spaces = r.getSpaces();
		var end, start = 1;
		var i = 0;
		for ( i = 0; i < spaces.length; i++ ) 
		{
			rows.push({
				chunk: i + 1,
				start: start,
				end: spaces[i] + 1
			});
			start = spaces[i] + 2;
		}

		// add the last row
		rows.push({
			chunk: i + 1,
			start: start,
			end: r.data.tN
		});

		// get the store and update it with the data
		list.getStore().loadData( { chunks: rows } );

		// set the colors in the table 
		var nodes = list.getNodes();
		
		for ( i = 0; i < nodes.length; i++ )
		{
			var node = Ext.get( nodes[i] );
			node.setStyle( 'background-color', 
					r.colors[ i % r.colors.length ] );
		}

        var sp = 0;
        if ( e )
            sp = r.getCmpId( e.target.id );
        if ( this.canFit() )
            r.recolor( sp );
        waiter.hide();
    },

    getCmpId: function( id ) {
        var match = id.match( /\d+/ );
        if ( match )
            return Number( match[0] );   // id # of space
        else
            return;
    },

    newText: function( text, tid ) {
        var spaces = this.getSpaces();
		this.killPanel();
        
        this.tid = tid;
		this.textData = text;
		
        this.makePanel();
		this.paint();
		this.doLayout();
		this.paint2();

        var w = Ext.get( this.data.cmp + 0 );
        if ( w && w.dom )
            w.dom.scrollIntoView();

        return spaces;
    },

	recolor: function( sp )	{
        sp = 0;

		var word = true; 	// starts with word
		var totalcolors = this.colors.length;
	    //var color = ( this.data.selectedSpaces.indexOf( sp ) != -1 ) ?
	    //    ( this.data.selectedSpaces.indexOf( sp ) + 1 ) % totalcolors
        //    : 0;
        var color = 0;    // start with color 0

        // highlight the whole thing first
        var i;
        for ( i = sp; i < this.data.tN; i++ ) {
            word = Ext.get( this.data.cmp + i );

            word.setStyle( 'background-color', this.colors[color] );

            if ( this.data.selectedSpaces.indexOf( i ) == -1 )
				;
            else
                color = ( color + 1 ) % totalcolors;
        }
	},

	emptySpaces: function() {
		//var l = this.getSpaces().length;
		/*var l = this.data.selectedSpaces.length;
		for ( var s = 0; s < l; s++ )
		{
			sp = this.data.selectedSpaces[0];
            var t = Ext.get( this.data.cmp + sp );
            this.clickSpace( null, t, null, true );
		}*/
        this.data.selectedSpaces = [];
	},

    addSpaces: function( arr ) {
        this.data.selectedSpaces = this.data.selectedSpaces.concat( arr );
    },

    removeSpaces: function( arr ) {
        for ( var i = 0; i < arr.length; i++ )
        {
            this.data.selectedSpaces 
                = this.data.selectedSpaces.remove( arr[i] );
        }
    },

    setSpaces: function( arr ) {
        this.emptySpaces();
        this.data.selectedSpaces = arr;
		/*var l = this.data.selectedSpaces.length;
		for ( var s = 0; s < l; s++ )
		{
			sp = this.data.selectedSpaces[s];
            var t = Ext.get( this.data.cmp + sp );
            this.clickSpace( null, t, null, true );
		}*/
    },

    getSpaces: function() {
        this.data.selectedSpaces.sort( function(a,b){ return a-b; } );
        return this.data.selectedSpaces;
    },

	clickSpace: function( e, t, o, tt ) {
        var r = t;
        if ( tt )
            r = t.dom;
        var p = Ext.getCmp( t.parentNode.id ).ownerCt;
        var i = Number(t.id.match( /\d+/ )[0]);   // id # of space
       
        // really want to select the previous space
        if ( !tt )
            i--;

        // if space is unselected, select it
        if ( p.data.selectedSpaces.indexOf(i) == -1 )//!r.selected )
		    p.addSpaces( [ i ] );
        else
            p.removeSpaces( [ i ] );

        p.updateTable(e,t,o);
	},

    canFit: function() {
        return this.data.tN < MAX_WORDS;
    },


	// functions called prior to rendering

	// private

    // stylize the spaces
    stylize: function() {
        if ( !this.canFit() )
            return;
        for ( var i = 1; i < this.data.tN; i++ )
        {
            var e = Ext.get( this.data.cmp + i );

			//e.addClassOnOver( 'cp-space-highlight' );
            e.on( 'click', this.clickSpace );
        }

    },

    cleanData: function() {
        this.textData = 
            this.textData.trim()
            .replace( />/g, "&gt;" )
            .replace( /</g, "&lt;" )
            //.replace( /[ \t\v\f]+/gi, ' ' )//.trim()
            //.replace( /^[ \t\v\f]+|[ \t\v\f]+$/, "" )
            //.replace( /[ ]+/gi, ' ' )
            //.replace( /\n+/gi, "\n" )
            ;
    },

	textArrayify: function() {
		this.data.textArray = this.textData.trim()
            .replace( /[ \t\r\f\v\n]+/gi, " " )
            .split( /[ ]+/gi );
	},

	spaceArrayify: function() {
		this.data.spaceArray = this.data.spaceString.trim()
            .replace( /\n+/gi, "\n" )
            .replace( /[^ \n]/gi, '' ).split( '' );
	},

    spaceStringer: function() {
        this.data.spaceString = this.textData.trim()
            // remove all doubles+ that are not newlines and replace with one
            .replace( /(\t)+/ig, '$1' )
            .replace( /( )+/ig, '$1' )
            .replace( /([\f\v\r])/ig, '' )
            // condense all space tabs to tabs
            .replace( /( \t)|(\t ) /gi, '\t' )
            // make all double+ newlines double newlines
            .replace( /(\n\n)+/ig, '$1' )
            // replaces all non spaces with nothing
            .replace( /\S/gi, '' )
            // replace space type with appropriate modifiers
            .replace( /\t/ig, 't' )
            .replace( / /ig, 's' )
            .replace( /\v/ig, '' )
            .replace( /\n\n/ig, 'd' )
            .replace( /\n/ig, 'n' )
            ;
    },

	// initializers and constructors

	initComponent: function() {
        this.makePanel();
    	CutterPanel.superclass.initComponent.apply( this, arguments );
	},

	listeners: {
		beforerender: function() {
			this.paint();
		},
		afterrender: function() {
			this.paint2();
			//this.getEl().on( 'click', this.updateTable );
		},
		render: function(c) {
		},
        beforedestroy: function() {
            this.killPanel();
        }
	},

    killPanel: function() {
        //this.emptySpaces();
        //this.emptyDom();

        this.data.textArray = null;
        this.data.spaceArray = null;
        
        this.data.spaceString = null;

        this.data.cmp = null;

        this.data.tN = null;
        this.data.sN = null;
        this.data.N = null;

        this.data.html = null;

		Ext.destroy( this.get(0) );

        //Ext.destroy( this );
    },

    emptyDom: function() {
        //for ( var i = 0; i < this.data.tN; i++ )
        //    Ext.destroy( this.data.cmp + i + '-w' );
        //this.getEl().update( '' );
    },

    makePanel: function() {

        this.data = {
            cmp: this.id + '-cmp-', // beginning of the name of each word/space

            textArray: Array(),     // array of words
            spaceArray: Array(),    // array of spaces

            spaceString: "",

            sN: 0,  // number of spaces
            tN: 0,  // number of words
            N: 0,   // number of spaces + words
            
            selectedSpaces: Array(),    // array of indices to selected spaces
            html: ""
        };

        this.cleanData();

        this.textArrayify();
        this.spaceStringer();
        //this.spaceArrayify();

        this.data.sN = this.data.spaceString.length;
        this.data.tN = this.data.textArray.length;
        this.data.N  = this.data.sN + this.data.tN;

        // make sure the text is small enough to work
        if ( !this.canFit() )
            return;

        var html = "";
        var cmp = "";
        var space;
        var i = 0;        // index into textArray and spaceArray
        for ( i = 0; i < this.data.tN - 1; i++ )
        {
            cmp = this.data.cmp + i;

            // don't add hover effect on first word
            if ( i == 0 )
                html += '<span title="' + (i + 1) + '" id="' + cmp + '" >' 
                    + this.data.textArray[i];
            else
                html += '<span title="' + (i + 1) + '" id="' + cmp + 
                    '" class="cp-space-highlight">' + this.data.textArray[i];

            space = this.data.spaceString[i];
            if ( space == 's' )
                html += ' ';
            else if ( space == 'n' )
                html += '<br/>';
            else if ( space == 't' )
                html += '&nbsp;&nbsp;&nbsp;&nbsp; ';
            else if ( space == 'd' )
                html += '<br/><br/>';
            else
                html += ' ';

            html += '</span>';

            //if ( space == 'n' )
              //  html += '<br class="cp-small-line"/>';

        }

        cmp = this.data.cmp + i;
        html += '<span title="' + (i + 1) + '" id="' + cmp + '" class="cp-space-highlight">' 
            + this.data.textArray[i] + '</span>';

        this.data.html = html;

    },

	paint: function() {
		var comp = new Ext.Component({html:this.data.html});
		this.add( comp );
		this.data.html = "";
	},

	paint2: function() {
        this.stylize();
        //this.updateTable( this.getSpaces(), this.data.tN );
		this.updateTable();
	}

});


Ext.reg( 'cutterpanel', CutterPanel );
