// diviText is a graphical text segmentation tool for use in text mining.
//     Copyright (C) 2011 Amos Jones and Lexomics Research Group
// 
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
// 
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
// 
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

/*onunload = function() {
    return confirm( "Are your sure you want to leave?" + 
             " Have you downloaded your texts yet?" );
}*/

Ext.onReady( function() {

    // load quick tips -- no idea what it does, but is alway included ???
    Ext.QuickTips.init();

    var cpupdater = new ChunkViewer({
        title: 'Chunk Viewer',
        id: 'cpupdater',
        border: true,
        autoWidth: false,
        cpid: 'cp'
    });

    var cutter    = new DiviCutter({
        id: 'cp',
        updater: cpupdater,
        renderTo: 'cutter-panel',
        border: false,
        autoScroll: true,
	    colors: [ '#eecd9c', '#eee9bc', '#d0ddd0', '#ddc4a6' ],
    });

    var downloadButton = new Ext.Button({
        text: 'Download Texts',
        icon: 'icons/disk.png',
        handler: function() {
            var body = Ext.getBody();
            var frame = body.createChild({
                tag:'iframe'
                ,cls:'x-hidden'
                ,id:'iframe'
                ,name:'iframe'
            });
                 
            var form = body.createChild({
                tag:'form'
                ,cls:'x-hidden'
                ,id:'form'
                ,action:'download.php'
                ,target:'iframe'
            });

            form.dom.submit();
        }
    });

    DiviViewport  = new Ext.Viewport({

        // layout config
        layout: 'border',

        // items
        items: [
            new Ext.BoxComponent({
                region: 'north',
                contentEl: 'header'
            }),
            new Ext.BoxComponent({
                region: 'south',
                contentEl: 'footer'
            }),
            {
				title: "Text Manager",
                region: 'west',
                split: true,
                //border: false,

                minSize: 100,
                width: 235,

                layout: 'fit',
                
                items: [{
                    layout: 'fit',
					border: false,
                    items: [ new TextViewer({id:'text-viewer'}) ]
                }],
				fbar:[{
					text: "Upload New Text",
					handler: Uploader,
                    icon: 'icons/book_add.png'
				},'-', downloadButton ]
            },
            {

                region: 'east',
                split: true,
                border: false,

                minSize: 100,
                width: 200,
                
                layout: 'border',

                items: [
                    {  
                        title: 'Chunk Viewer',
                        split: true,
                        region: 'center',
                        layout: 'vbox',
                        layoutConfig: {
                            align: 'stretch',
                            pack: 'start'
                        },
                        items: [ 
                            Ext.apply( cutter.updater, {flex:1} )
                        ]

                    }, 
                    {    
                        title: 'Cutting Tools',
                        height: 400,
                        region: 'south',
                        split: true,
                        layout: 'fit',
                        items:[ 
                            new AutoCutter({
                                cutterPanel: cutter
                            }) 
                        ]
                    }
                ]
            },
            {
                id: 'cutter-panel-panel',
                title: 'Visual Cutter -- No Text',

                region: 'center',
                split: true,

                layout: 'fit',

                items: [ cutter ]
            }
        ]

    });

    cutter.reset();
});


DiviCutter = Ext.extend( CutterPanel, {
    textData: '',

    getDefaultText: function() {
        var cp = this;
        Ext.Ajax.request({
            method: 'POST',
            url: 'defaultText.txt',
            success: function(r,o) {
                cp.newText( r.responseText, null );
                var ftb = cp.getFooterToolbar();
                if ( ftb )
                    ftb.disable();
            }
        });
    },

    finalize: function( name ) {
        var textid = this.tid;
        var spacestr = Ext.encode( this.getSpaces() );

        if ( !textid || !name )
            return;

        var ftb = this.getFooterToolbar();
        if ( ftb )
            ftb.disable();

        Ext.Ajax.request({
            url: 'modules/texts/chunk.php',
            method: 'POST',
            params: {
                name: name,
                textid: textid,
                spaces: spacestr
            },
            success: function( r, o ) {
                var tv = Ext.getCmp( 'text-viewer' );
                tv._reload();
                tv.getRootNode().expand( true );
                if ( ftb )
                {
                    ftb.enable();
                    ftb.get( 'chunkset-name' ).setValue( '' );
                }
            },
            failure: function( r, o ) {
                var response = Ext.decode( r.responseText );
                var errors = response.errors;
                report_errors( errors, "Chunking Error" );
            }
        });

    },

    initComponent: function() {
        this.getDefaultText();
        var cp = this;
        var namefield = new EnterField({
            id: 'chunkset-name',
            fieldLabel: "Chunkset Name",
            xtype: 'textfield',
            anchor: '50%',
            allowBlank: false            
        });
        function enterSubmit() {
            this.finalize( namefield.getValue() );
        };
        var chunkerbar = new Ext.Toolbar({
            disabled: true,
            items: [
                "Chunkset Name:",
                namefield,
            {
                text: "Save Chunkset",
                icon: 'icons/page_white_stack_add.png',
                handler: enterSubmit,
                scope: cp
                       
            },{
                text: "Reset",
                icon: 'icons/arrow_undo.png',
                handler: cp.reset,
                scope: cp
            }]
        });
        Ext.apply( this, {
            fbar: chunkerbar
        });
        DiviCutter.superclass.initComponent.apply( this, arguments );
    }


});

// == Auto Cutter Builders ============
// lower left accordion thing

CutterType = Ext.extend( Ext.form.FormPanel, {
    border: false,
    labelAlign: 'top',
    layout: 'form',
    defaults: {
        anchor: '100%',
        border: false
    },

    enterSubmit: function( ) {
        var form = this.getForm();

        if ( form.isValid() )
        {
            this.callCut( form.getValues() );
        }
    },

    initComponent: function() {
        Ext.apply( this, {
            buttons: [
                {
                    formBind: true,
                    text: 'Cut',
                    icon: 'icons/cut.png',
                    handler: function() {
                        var fp = this.ownerCt.ownerCt,
                            form = fp.getForm();
                        fp.enterSubmit();
                    }
                }
            ]
        });
        CutterType.superclass.initComponent.apply( this, arguments );
    }
});

EnterField = Ext.extend( Ext.form.Field, {
    enableKeyEvents: true,
    listeners: {
        specialKey: function( field, e ) {
            if ( e.getKey() == e.ENTER )
            {
                var fp = this.ownerCt;
                fp.enterSubmit();
            }
        }
    }
});

SimpleCutter = Ext.extend( CutterType, {

    initComponent: function() {
        Ext.apply( this, {
            items: [
                new EnterField({
                    xtype: 'numberfield',
                    fieldLabel: 'Chunks',
                    name: 'chunks',
                    allowNegative: false
                })
            ]
        });
        SimpleCutter.superclass.initComponent.apply( this, arguments );
    },

    callCut: function( v ) {
        this.cutterPanel.oneParamSpacer( new Number( v.chunks ) );
        var csname = Ext.getCmp( 'chunkset-name' );
        if ( !csname.getValue() )
        {
            csname.setValue( v.chunks + "_chunks" );
        }
    }
});

AdvancedCutter = Ext.extend( CutterType, {
    initComponent: function() {
        Ext.apply( this, {
            items: [
                new EnterField({
                    xtype: 'numberfield',
                    fieldLabel: 'Size',
                    name: 'size',
                    allowNegative: false
                }),
                new Ext.form.SliderField({
                    fieldLabel: 'Last Proportion',
                    name: 'last',
                    minValue: .01,
                    maxValue: 1,
                    increment: .01,
                    decimalPrecision: 2,
                    value: .5
                })
            ]
        });
        AdvancedCutter.superclass.initComponent.apply( this, arguments );
    },

    callCut: function( v ) {
        this.cutterPanel.threeParamSpacer( 
                new Number( v.size ), 0, new Number( v.last ) );
        var csname = Ext.getCmp( 'chunkset-name' );
        if ( !csname.getValue() )
        {
            csname.setValue( v.size + "_words_" + v.last );
        }
    }
});

AutoCutter = Ext.extend( Ext.Container, {
    border: false,
    height: 400,
    
    layout: 'accordion',
    layoutConfig: {
        animate: true
    },

    initComponent: function() {
        var cp = this.cutterPanel;
        Ext.apply( this, {
            defaults: {
                padding:5,
            },
            items: [
                {
                    title: 'Simple (by # of Chunks)',
                    border: false,
                    items: [ new SimpleCutter({
                        cutterPanel: cp
                    }),{
                        contentEl: 'help-simple',
                        border: false
                    }]
                },{
                    title: 'Advanced (by Chunk Size)',
                    border: false,
                    items: [ new AdvancedCutter({
                        cutterPanel: cp
                    }),{
                        contentEl: 'help-advanced',
                        border: false
                    }]
                },{
                    title: 'Visual Cutter - Info',
                    border: false,
                    contentEl: 'help-visual'
                }
            ]
        });
        AutoCutter.superclass.initComponent.apply( this, arguments );
    },
});

// == TextViewer ======================
// viewer and uploader for texts

TextViewer = Ext.extend( Ext.tree.TreePanel, {
	border: false,
	
	root: {
		id: 'texts',
		text: 'Uploaded Library',
        icon: 'icons/package.png',
		expanded: true
	},

	dataUrl: 'modules/texts/gettexts.php',

    
    selectText: function( id, spaces ) {
        var waiter = Ext.Msg.wait( "Please wait while building text.", 
            "Loading Text" );

        var cp = Ext.getCmp( 'cp' );
        var ftb = cp.getFooterToolbar();

        if ( ftb )
            ftb.disable();

        var cpp = Ext.getCmp( 'cutter-panel-panel' );

        if ( cp.tid == id )
        {
            if ( spaces )
            {
                cp.setSpaces( spaces );
                cp.updateTable();
            }
            ftb.enable();
            waiter.hide();
            return;
        }
        Ext.Ajax.request({
            url: 'modules/texts/gettext.php',
            method: 'POST',
            params: {
                textid: id
            },
            success: function( r, o ) {
                
                var response = Ext.decode( r.responseText );
                var text = response.text;
                var textname = response.name;
                var size = response.size;
                var errors = response.errors;
                
                if ( text )
                {
                    cp.newText( text, id );
                    cpp.setTitle( "Visual Cutter -- " + textname );
                    if ( spaces )
                    {
                        cp.setSpaces( spaces );
                        cp.updateTable();
                    }
                    if ( !cp.canFit() )
                    {
                        waiter.hide();

                        if ( ftb )
                            ftb.enable();
                        Ext.Msg.alert( "Text Too Big",
                            "Text is too big to fit in Visual" +
                            " Cutter Panel, but you can use the Auto" +
                            " Cutters in the lower right." );
                        cpp.setTitle( "Visual Cutter -- No Text -- " + 
                            textname );
                    }
                }
                else
                    report_errors( errors, "Text Retrival Error" );

                waiter.hide();

                if ( ftb )
                    ftb.enable();
            },
            failure: function( r, o ) {
                var response = Ext.decode( r.responseText );
                var errors = response.errors;

                report_errors( errors, "Text Retrival Error" );

                if ( ftb )
                    ftb.enable();
            }
        });
    },

    deleteText: function( id ) {
        Ext.Ajax.request({
            url: 'modules/file/removetext.php',
            method: 'POST',
            params: {
                textid: id
            },
            success: function( r, o ) {
                var response = Ext.decode( r.responseText );
				var tv = Ext.getCmp( 'text-viewer' );
                var cp = Ext.getCmp( 'cp' );
                if ( id == cp.tid )
                    cp.newText( '', null );// FIX IT
				tv._reload();
                tv.getRootNode().expand();
            },
            failure: function( r, o ) {
                var response = Ext.decode( r.responseText );
                var errors = response.errors;

                report_errors( errors, "Text Removal Error" );
            }
        });

    },

  /*  showChunkset: function( tid, csid ) {
        selectText( tid );
    },*/

    deleteChunkset: function( tid, csid ) {
        Ext.Ajax.request({
            url: 'modules/texts/unchunk.php',
            method: 'POST',
            params: {
                textid: tid,
                csid: csid
            },
            success: function( r, o ) {
                var response = Ext.decode( r.responseText );
				var tv = Ext.getCmp( 'text-viewer' );
                var cp = Ext.getCmp( 'cp' );
                //if ( id == cp.tid )
                //    cp.newText( '', null );// FIX IT
				tv._reload();
                tv.getRootNode().expand();
            },
            failure: function( r, o ) {
                var response = Ext.decode( r.responseText );
                var errors = response.errors;

                report_errors( errors, "Chunkset Removal Error" );
            }
        });

    },

	_reload: function() {
		this.getLoader().load( this.root );
	},

	initComponent: function() {
		Ext.apply( this, {

			defaults: {
				expanded: true,
				border: false
	 	    },

		});
		TextViewer.superclass.initComponent.apply( this, arguments );
	},

	listeners: {
		click: function( n, e ) {
            if ( n != this.getRootNode() && n.attributes.type == 'text' )
                this.selectText( n.attributes.tid );
            else if ( n.attributes.type == 'chunkset' )
                this.selectText( n.parentNode.attributes.tid, 
                    n.attributes.spaces );
		},
        contextmenu: function( n, e ) {
            //n.select();

            var c, t = n.getOwnerTree();
            var type = n.attributes.type;
            if ( type == 'chunkset' )
                c = t.contextChunksetMenu();
            else if ( type == 'text' )
                c = t.contextTextMenu();
            else
                return;

            c.contextNode = n;
            c.showAt( e.getXY() );
        }
	},

    contextTextMenu: function() {
        return new Ext.menu.Menu({
            items:[{
                id: 'delete',
                text: 'Remove Text'
            },{
                id: 'show',
                text: 'Show Text'
            }],

            listeners: {
                itemclick: function( item ) {
                    var n = item.parentMenu.contextNode;
                    var t = n.getOwnerTree();
                    switch ( item.id )
                    {
                        case 'delete' : 
                            t.deleteText( n.attributes.tid );
                            break;

                        case 'show' :
                            t.selectText( n.attributes.tid );
                            break;
                    }
                }
            }
        });
    },

    contextChunksetMenu: function() {
        return new Ext.menu.Menu({
            items:[{
                id: 'show',
                text: 'Show Chunkset'
            },{
                id: 'delete',
                text: 'Remove Chunkset'
            }],

            listeners: {
                itemclick: function( item ) {
                    var n = item.parentMenu.contextNode;
                    var t = n.getOwnerTree();
                    switch ( item.id )
                    {
                        case 'delete' : 
                            t.deleteChunkset( n.parentNode.attributes.tid, 
                                n.attributes.tid );
                            break;

                        case 'show' :
                            t.selectText( n.parentNode.attributes.tid, 
                                n.attributes.spaces );
                            break;
                    }
                }
            }
        });
    }
});

Uploader = function() {
	var win = new UploaderWindow({id:'uploader-window'});
	win.show();
}

UploaderWindow = Ext.extend( Ext.Window, {
	title: "Text Uploader",
	width: 500,	
	initComponent: function() {
		Ext.apply( this, {
			items: [ new UploaderForm({}) ]
		});
		UploaderWindow.superclass.initComponent.apply( this, arguments );
	}
});

UploaderForm = Ext.extend( Ext.form.FormPanel, {
	border: false,
	
	padding: 5,
	layout: 'form',

	fileUpload: true,

	enterSubmit: function() {
        this.upload();
	},

	upload: function() {
		if ( this.getForm().isValid() )
		{
			this.getForm().submit({
				url: 'modules/file/uploadtext.php',
				method: 'POST',
				waitMsg: 'Uploading text... May take a while.',
				success: function(f,a) {
					var path = "/texts/" + a.result.textpath;
					var tv = Ext.getCmp( 'text-viewer' );
					
					tv._reload();
					tv.getRootNode().expand( true );
					//tv.expandPath( path );
					Ext.getCmp( 'uploader-window' ).close();
				},
				failure: function(f,a) {
					report_errors( a.result.errors, "Upload Error" );
				}
			});
		}
	},

	initComponent: function() {
		var fp = this;
		var namefield = new EnterField({
			fieldLabel: 'Text Name',
			name: 'name',
			allowBlank: false
		});

		var filefield = {
			xtype: 'fileuploadfield',
			fieldLabel: 'File',
			name: 'file',
			listeners: {
				fileselected: function(f,file) {
					var name = file.match( /[^\\\/]+\..{3}/ );
					if ( name )
						namefield.setValue( name );
					else 
						namefield.setValue( file );
				}
			}
		};

		Ext.apply( this, {
			defaults: {
				anchor: '100%',
				xtype: 'textfield'
		    },

			items: [ filefield, namefield ],

			buttons: [{
				text: "Upload",
				scope: fp,
				handler: fp.upload
			}]
		});
		UploaderForm.superclass.initComponent.apply( this, arguments );
	}
});



// == General Handling Functions ====================================

// report_errors
function report_errors( errors, title ) {

    var out = "";

    for ( var i = 0; i < errors.length; i++ ) 
    {
        out += "\n" + (i+1) + ". " + errors[i];
    }

    Ext.Msg.alert( title, out );

}
